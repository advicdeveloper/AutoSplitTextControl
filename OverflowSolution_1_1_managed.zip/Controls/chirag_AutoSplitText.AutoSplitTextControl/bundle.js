/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./AutoSplitTextControl/index.ts":
/*!***************************************!*\
  !*** ./AutoSplitTextControl/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   AutoSplitTextControl: () => (/* binding */ AutoSplitTextControl)\n/* harmony export */ });\nclass AutoSplitTextControl {\n  constructor() {\n    this._field2MaxLength = 4000; // Removed : number to fix ESLint error\n  }\n  init(context, notifyOutputChanged, state, container) {\n    var _a;\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    // Get maxLength for field1, default to 4000 if invalid, cap at 4000\n    var maxLengthRaw = (_a = context.parameters.maxLength) === null || _a === void 0 ? void 0 : _a.raw;\n    this._field1MaxLength = maxLengthRaw && !isNaN(maxLengthRaw) && maxLengthRaw > 0 ? Math.min(maxLengthRaw, 4000) : 4000;\n    console.log(\"init maxLength:\", this._field1MaxLength);\n    // Create wrapper for field1\n    var field1Wrapper = document.createElement(\"div\");\n    field1Wrapper.className = \"input-wrapper\";\n    // Create label for field1\n    var field1Label = document.createElement(\"label\");\n    field1Label.textContent = \"Primary Text\";\n    field1Label.htmlFor = \"field1-input\";\n    field1Label.className = \"input-label\";\n    // Create input for field1\n    this._field1Input = document.createElement(\"textarea\");\n    this._field1Input.id = \"field1-input\";\n    this._field1Input.className = \"text-input\";\n    this._field1Input.value = (context.parameters.field1.raw || \"\").substring(0, this._field1MaxLength);\n    this._field1Input.maxLength = this._field1MaxLength;\n    this._field1Input.addEventListener(\"input\", this.onInput.bind(this));\n    this._field1Input.placeholder = \"Enter text (max \".concat(this._field1MaxLength, \" characters)\");\n    // Create counter for field1\n    this._field1Counter = document.createElement(\"span\");\n    this._field1Counter.className = \"char-counter\";\n    this._field1Counter.textContent = \"\".concat(this._field1Input.value.length, \"/\").concat(this._field1MaxLength);\n    // Append label, input, and counter to field1 wrapper\n    field1Wrapper.appendChild(field1Label);\n    field1Wrapper.appendChild(this._field1Input);\n    field1Wrapper.appendChild(this._field1Counter);\n    // Create wrapper for field2\n    var field2Wrapper = document.createElement(\"div\");\n    field2Wrapper.className = \"input-wrapper\";\n    // Create label for field2\n    var field2Label = document.createElement(\"label\");\n    field2Label.textContent = \"Overflow Text\";\n    field2Label.htmlFor = \"field2-input\";\n    field2Label.className = \"input-label\";\n    // Create input for field2\n    this._field2Input = document.createElement(\"textarea\");\n    this._field2Input.id = \"field2-input\";\n    this._field2Input.className = \"text-input\";\n    this._field2Input.value = (context.parameters.field2.raw || \"\").substring(0, this._field2MaxLength);\n    this._field2Input.maxLength = this._field2MaxLength;\n    this._field2Input.addEventListener(\"input\", this.onInput.bind(this));\n    this._field2Input.placeholder = \"Overflow text (max \".concat(this._field2MaxLength, \" characters)\");\n    // Create counter for field2\n    this._field2Counter = document.createElement(\"span\");\n    this._field2Counter.className = \"char-counter\";\n    this._field2Counter.textContent = \"\".concat(this._field2Input.value.length, \"/\").concat(this._field2MaxLength);\n    // Append label, input, and counter to field2 wrapper\n    field2Wrapper.appendChild(field2Label);\n    field2Wrapper.appendChild(this._field2Input);\n    field2Wrapper.appendChild(this._field2Counter);\n    // Append wrappers to container\n    this._container.appendChild(field1Wrapper);\n    this._container.appendChild(field2Wrapper);\n    // Initialize values\n    this._field1Value = this._field1Input.value;\n    this._field2Value = this._field2Input.value;\n  }\n  onInput() {\n    var field1Length = this._field1Input.value.length;\n    if (field1Length >= this._field1MaxLength) {\n      this._field1Input.classList.add(\"text-input--limit-reached\");\n      var excessText = this._field1Input.value.substring(this._field1MaxLength);\n      this._field1Input.value = this._field1Input.value.substring(0, this._field1MaxLength);\n      this._field2Input.value = (excessText + this._field2Input.value).substring(0, this._field2MaxLength);\n      this._field2Input.focus();\n    } else {\n      this._field1Input.classList.remove(\"text-input--limit-reached\");\n    }\n    this._field1Value = this._field1Input.value.substring(0, this._field1MaxLength);\n    this._field2Value = this._field2Input.value.substring(0, this._field2MaxLength);\n    this._field1Counter.textContent = \"\".concat(this._field1Input.value.length, \"/\").concat(this._field1MaxLength);\n    this._field2Counter.textContent = \"\".concat(this._field2Input.value.length, \"/\").concat(this._field2MaxLength);\n    this._notifyOutputChanged();\n    console.log(\"onInput:\", {\n      field1: this._field1Value.length,\n      field2: this._field2Value.length\n    });\n  }\n  updateView(context) {\n    var _a;\n    var maxLengthRaw = (_a = context.parameters.maxLength) === null || _a === void 0 ? void 0 : _a.raw;\n    var newMaxLength = maxLengthRaw && !isNaN(maxLengthRaw) && maxLengthRaw > 0 ? Math.min(maxLengthRaw, 4000) : 4000;\n    if (newMaxLength !== this._field1MaxLength) {\n      this._field1MaxLength = newMaxLength;\n      this._field1Input.maxLength = this._field1MaxLength;\n      this._field1Input.placeholder = \"Enter text (max \".concat(this._field1MaxLength, \" characters)\");\n      this._field1Input.value = this._field1Input.value.substring(0, this._field1MaxLength);\n      this._field1Counter.textContent = \"\".concat(this._field1Input.value.length, \"/\").concat(this._field1MaxLength);\n      console.log(\"updateView maxLength:\", this._field1MaxLength);\n    }\n    if (this._field1Value !== context.parameters.field1.raw) {\n      this._field1Input.value = (context.parameters.field1.raw || \"\").substring(0, this._field1MaxLength);\n      this._field1Value = this._field1Input.value;\n    }\n    if (this._field2Value !== context.parameters.field2.raw) {\n      this._field2Input.value = (context.parameters.field2.raw || \"\").substring(0, this._field2MaxLength);\n      this._field2Value = this._field2Input.value;\n    }\n    this._field1Counter.textContent = \"\".concat(this._field1Input.value.length, \"/\").concat(this._field1MaxLength);\n    this._field2Counter.textContent = \"\".concat(this._field2Input.value.length, \"/\").concat(this._field2MaxLength);\n    console.log(\"updateView:\", {\n      field1: this._field1Value.length,\n      field2: this._field2Value.length\n    });\n  }\n  getOutputs() {\n    var outputs = {\n      field1: this._field1Value,\n      field2: this._field2Value\n    };\n    var targetFieldLogicalName = this._context.parameters.targetFieldLogicalName.raw;\n    if (targetFieldLogicalName) {\n      outputs[targetFieldLogicalName] = this._field2Value;\n    }\n    console.log(\"getOutputs:\", {\n      field1: this._field1Value.length,\n      field2: this._field2Value.length,\n      targetFieldLogicalName\n    });\n    return outputs;\n  }\n  destroy() {\n    this._field1Input.removeEventListener(\"input\", this.onInput);\n    this._field2Input.removeEventListener(\"input\", this.onInput);\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AutoSplitTextControl/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./AutoSplitTextControl/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('AutoSplitText.AutoSplitTextControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoSplitTextControl);
} else {
	var AutoSplitText = AutoSplitText || {};
	AutoSplitText.AutoSplitTextControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoSplitTextControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}