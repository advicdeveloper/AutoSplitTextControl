// import { IInputs, IOutputs } from "./generated/ManifestTypes";

// export class AutoSplitTextControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
//     private _context: ComponentFramework.Context<IInputs>;
//     private _container: HTMLDivElement;
//     private _field1Input: HTMLTextAreaElement;
//     private _field2Input: HTMLTextAreaElement;
//     private _field1Value: string;
//     private _field2Value: string;
//     private _maxLength = 100;
//     private _notifyOutputChanged: () => void;

//     public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
//         this._context = context;
//         this._notifyOutputChanged = notifyOutputChanged;
//         this._container = container;

//         // Create input for field1
//         this._field1Input = document.createElement("textarea");
//         this._field1Input.className = "text-input";
//         this._field1Input.value = context.parameters.field1.raw || "";
//         this._field1Input.addEventListener("input", this.onInput.bind(this));
//         this._field1Input.placeholder = "Enter text (max 4000 characters)";

//         // Create input for field2
//         this._field2Input = document.createElement("textarea");
//         this._field2Input.className = "text-input";
//         this._field2Input.value = context.parameters.field2.raw || "";
//         this._field2Input.addEventListener("input", this.onInput.bind(this));
//         this._field2Input.placeholder = "Overflow text (max 4000 characters)";

//         // Append inputs to container
//         this._container.appendChild(this._field1Input);
//         this._container.appendChild(this._field2Input);

//         // Initialize values
//         this._field1Value = context.parameters.field1.raw || "";
//         this._field2Value = context.parameters.field2.raw || "";
//     }

//     private onInput(): void {
//         const field1Length = this._field1Input.value.length;

//         if (field1Length >= this._maxLength) {
//             this._field1Input.value = this._field1Input.value.substring(0, this._maxLength);
//             this._field2Input.focus();
//         }

//         this._field1Value = this._field1Input.value;
//         this._field2Value = this._field2Input.value;
//         this._notifyOutputChanged();
//     }

//     public updateView(context: ComponentFramework.Context<IInputs>): void {
//         this._field1Input.value = context.parameters.field1.raw || "";
//         this._field2Input.value = context.parameters.field2.raw || "";
//         this._field1Value = context.parameters.field1.raw || "";
//         this._field2Value = context.parameters.field2.raw || "";
//     }

//     public getOutputs(): IOutputs {
//         return {
//             field1: this._field1Value,
//             field2: this._field2Value
//         };
//     }

//     public destroy(): void {
//         // Clean up event listeners
//         this._field1Input.removeEventListener("input", this.onInput);
//         this._field2Input.removeEventListener("input", this.onInput);
//     }
// }


import { IInputs, IOutputs } from "./generated/ManifestTypes";

export class AutoSplitTextControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _context: ComponentFramework.Context<IInputs>;
    private _container: HTMLDivElement;
    private _field1Input: HTMLTextAreaElement;
    private _field2Input: HTMLTextAreaElement;
    private _field1Value: string;
    private _field2Value: string;
    private _maxLength = 100;
    private _notifyOutputChanged: () => void;

    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this._context = context;
        this._notifyOutputChanged = notifyOutputChanged;
        this._container = container;

        const field1Wrapper = document.createElement("div");
        field1Wrapper.className = "input-wrapper";

        const field1Label = document.createElement("label");
        field1Label.textContent = "Primary Text";
        field1Label.htmlFor = "field1-input";
        field1Label.className = "input-label";

        // Create input for field1
        this._field1Input = document.createElement("textarea");
        this._field1Input.id = "field1-input";
        this._field1Input.className = "text-input";
        this._field1Input.value = context.parameters.field1.raw || "";
        this._field1Input.addEventListener("input", this.onInput.bind(this));
        this._field1Input.placeholder = "Enter text";

        // Append label and input to field1 wrapper
        field1Wrapper.appendChild(field1Label);
        field1Wrapper.appendChild(this._field1Input);

        // Create wrapper for field2
        const field2Wrapper = document.createElement("div");
        field2Wrapper.className = "input-wrapper";

        // Create label for field2
        const field2Label = document.createElement("label");
        field2Label.textContent = "Overflow Text";
        field2Label.htmlFor = "field2-input";
        field2Label.className = "input-label";

        // Create input for field2
        this._field2Input = document.createElement("textarea");
        this._field2Input.id = "field2-input";
        this._field2Input.className = "text-input";
        this._field2Input.value = context.parameters.field2.raw || "";
        this._field2Input.addEventListener("input", this.onInput.bind(this));
        this._field2Input.placeholder = "Overflow text";

        // Append label and input to field2 wrapper
        field2Wrapper.appendChild(field2Label);
        field2Wrapper.appendChild(this._field2Input);

        // Append wrappers to container
        this._container.appendChild(field1Wrapper);
        this._container.appendChild(field2Wrapper);

        // Initialize values
        this._field1Value = context.parameters.field1.raw || "";
        this._field2Value = context.parameters.field2.raw || "";
    }

    private onInput(): void {
        const field1Length = this._field1Input.value.length;

        if (field1Length >= this._maxLength) {
            this._field1Input.value = this._field1Input.value.substring(0, this._maxLength);
            this._field2Input.focus();
        }

        this._field1Value = this._field1Input.value;
        this._field2Value = this._field2Input.value;
        this._notifyOutputChanged();
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this._field1Input.value = context.parameters.field1.raw || "";
        this._field2Input.value = context.parameters.field2.raw || "";
        this._field1Value = context.parameters.field1.raw || "";
        this._field2Value = context.parameters.field2.raw || "";
    }

    public getOutputs(): IOutputs {
        return {
            field1: this._field1Value,
            field2: this._field2Value
        };
    }

    public destroy(): void {
        this._field1Input.removeEventListener("input", this.onInput);
        this._field2Input.removeEventListener("input", this.onInput);
    }
}